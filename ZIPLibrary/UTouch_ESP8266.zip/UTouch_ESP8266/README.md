# UTouch_ESP8266
* UTouch by Rinky-Dink Electronics, Henning Karlsen.
* Modified by Richard Bushill to use hardware SPI instead of bit bang
* Minor modifications by InsanityMoose for ESP8266
