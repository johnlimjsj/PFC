/*
i2cdetect.h - Arduino library for scanning I2C bus for devices
*/

#ifndef I2C_HELPER_H
#define I2C_HELPER_H

void i2cdetect(uint8_t first, uint8_t last);
void i2cdetect();

class I2C_helper{
	public:
		static void writeI2cRegister8Bit(int addr, int val);
		static void writeI2cRegisterFloat(int addr, float val);
		static int requestI2cInteger(int addr, int numBits);
		static float requestI2cFloat(int addr);

	private:
};

#endif
