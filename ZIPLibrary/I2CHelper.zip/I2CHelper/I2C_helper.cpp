/*
i2cdetect.cpp - Arduino library for scanning I2C bus for devices
*/

#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

#include "Wire.h"
#include "I2C_helper.h"


typedef union float2bytes_t   // union consists of one variable represented in a number of different ways 
{ 
  float f; 
  byte b[sizeof(float)]; 
}; 
float2bytes_t f2b_write; 
float2bytes_t f2b_read; 


void I2C_helper::writeI2cRegister8Bit(int addr, int val){
  Wire.beginTransmission(addr);
  Wire.write(val);
  Wire.endTransmission();
}

void I2C_helper::writeI2cRegisterFloat(int addr, float val){
  f2b_write.f = val;
  Wire.beginTransmission(addr);
  Wire.write(f2b_write.b, sizeof(float));
  Wire.endTransmission(); 
}

int I2C_helper::requestI2cInteger(int addr, int numBits){
  Wire.requestFrom(addr, numBits);
  int numBitsReceived = Wire.available();
  int received = 0;
  for(int i=0; i<numBitsReceived; i++){
    byte receivedByte = Wire.read();
    received = received | (receivedByte << 8*i);
  }
  return received;
}

float I2C_helper::requestI2cFloat(int addr){
  Wire.requestFrom(addr, sizeof(float));
  if(Wire.available() > 0){
    f2b_read.b[0] = Wire.read();
    f2b_read.b[1] = Wire.read();
    f2b_read.b[2] = Wire.read();
    f2b_read.b[3] = Wire.read();
  }
  return f2b_read.f;
}


// =========================================================


void i2cdetect(uint8_t first, uint8_t last) {
  uint8_t i, address, error;
  char buff[10];

  // table header
  Serial.print("   ");
  for (i = 0; i < 16; i++) {
    //Serial.printf("%3x", i);
    sprintf(buff, "%3x", i);
    Serial.print(buff);
  }

  // table body
  // addresses 0x00 through 0x77
  for (address = 0; address <= 119; address++) {
    if (address % 16 == 0) {
      //Serial.printf("\n%#02x:", address & 0xF0);
      sprintf(buff, "\n%02x:", address & 0xF0);
      Serial.print(buff);
    }
    if (address >= first && address <= last) {
      Wire.beginTransmission(address);
      error = Wire.endTransmission();
      if (error == 0) {
        // device found
        //Serial.printf(" %02x", address);
        sprintf(buff, " %02x", address);
        Serial.print(buff);
      } else if (error == 4) {
        // other error
        Serial.print(" XX");
      } else {
        // error = 2: received NACK on transmit of address
        // error = 3: received NACK on transmit of data
        Serial.print(" --");
      }
    } else {
      // address not scanned
      Serial.print("   ");
    }
  }
  Serial.println("\n");
}

void i2cdetect() {
  i2cdetect(0x03, 0x77);  // default range
}

